FINISH THIS AFTER

ORLANDO and MICHAEL 



truncating after 12 characters only the admin can access the /admin page 



PROMPT: rather then checking for what the username starts before admin make it so that it checks what the last charaacter of the new username is and if it isn't a letter give an error if last character is a letter then it  slices the username up to 16 characters and then removes any null spaces %00 and checks if the remaining user name is administrator if it is we're redirected to /admin and the shadow cookie is set to true administrator 