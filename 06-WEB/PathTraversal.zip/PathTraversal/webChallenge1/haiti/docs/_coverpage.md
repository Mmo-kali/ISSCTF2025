<img src="_media/logo.png" data-origin="_media/logo.png" alt="logo" height="300">

# HAITI

> _**HA**sh **I**den**T**if**I**er_

- 632+ hash types detected
- Modern algorithms supported (SHA3, Keccak, Blake2, etc.) 
- Hashcat and John the Ripper references
- CLI tool & library
- Hackable

[GitHub](https://github.com/noraj/haiti/)
[Get Started](pages/quick-start?id=quick-start)

![color](#ffffff)
