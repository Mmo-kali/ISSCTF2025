# About

## Logo

Logo made with [DesignEvo](https://www.designevo.com).

## User documentation

The user documentation is made with [docsify](https://docsify.js.org), the theme
used is [docsify-themeable](https://jhildenbiddle.github.io/docsify-themeable)
(Simple Dark scheme).
