# Demonstration

haiti 2.0.0

[![asciicast](https://asciinema.org/a/620572.svg)](https://asciinema.org/a/620572)

john-haiti 2.1.0

[![asciicast](https://asciinema.org/a/620583.svg)](https://asciinema.org/a/620583)

haiti-fzf 2.1.0

[![asciicast](https://asciinema.org/a/620584.svg)](https://asciinema.org/a/620584)

## Archive

haiti 0.0.1

[![asciicast](https://asciinema.org/a/274703.svg)](https://asciinema.org/a/274703)
