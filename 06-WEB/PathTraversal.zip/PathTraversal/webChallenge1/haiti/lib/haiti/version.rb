# frozen_string_literal: true

module Version
  VERSION = '2.1.0'
end
