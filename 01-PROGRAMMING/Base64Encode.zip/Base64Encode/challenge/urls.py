from django.urls import path

from . import views

urlpatterns = [
    path("challenge", views.index, name="index"),
]