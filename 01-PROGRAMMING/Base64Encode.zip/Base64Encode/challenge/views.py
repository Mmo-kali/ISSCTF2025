# ----------------------------------------------------------------------
# Black Hat Bureau CTF Programming Challenge:
# Base64Encode
# Dev: Joel Dykstra (OtterTeamSix)
# Last Updated: May 5, 2024
#
# A programming challenge where a user must encode a randomly generated
# 80 byte hex string into base64 and submit it back to the webpage
# within a very short time period (eg: 3 seonds) to successfully retrieve
# the flag. A python file for the solution is included in the folder
#
# TODO: Adjust the challenge description to make it fit into the
#       event theme. Currently, the challenge is functional but needs
#       better CSS styling and the above mentioned theme updates.
# ----------------------------------------------------------------------


from django.shortcuts import render
import os, base64
# --------------------------------
# Global Variables for easy adjustment
# --------------------------------
FLAG = "bhbureauCTF{TBD}"
CHALLENGE_TITLE = "Programming Base64"
TIME_LIMIT = 3

CHALLENGE_DESCRIPTION = "Encode the following string as base64. <br>"
CHALLENGE_DESCRIPTION += "You have " + str(TIME_LIMIT) + " seconds to send your reply to: <br>"

# --------------------------------
# Defined functions for challenge
# --------------------------------
def generate():
    """Generates a random 80 character hexstring using the built in os random byte generation
    with the urandom() funtion and then converting it to hex
    
    Parameters
    ----------
    None
 
    Returns
    -------
    str
        Randomly generated hexstring of length 80
    """
    bytesString = os.urandom(80)
    output = bytesString.hex()
    return output

# --------------------------------
# Function Based Views
# --------------------------------

def index(request):
    """
    Main page of the challenge. On first load it generates a hexstring,
    creates a session with the hexstring and a very short expiry before
    rendering the html template to the user.

    User will send the encoded answer to this page with a get request.
    On this load, it verifies that the session isn't expired, then compares
    the submitted answer with the encoded stored string in the session. If 
    correct, it renders the html template with the flag as the data.
    """

    # Clear all expired sessions and get any valid session data plus any 
    # supplied answer
    request.session.clear_expired()
    data = request.session.get('data')
    answer = request.GET.get('answer')

    # Check to see if both an answer and a valid session are present
    if(data != None and answer != None):
        
        # Check if answer is correct
        if (base64.b64encode(data.encode("ascii")).decode() == answer):
            # Set flag as outputted data
            data=FLAG
        
        # Not correct, regenerate page with new data and session
        else:
            data = generate()
            request.session['data'] = data
            request.session.set_expiry(TIME_LIMIT)
    # First load of Page, expired session, or no answer provided
    else:
        # Generate data, add it to the session and set the expiry
        data = generate()
        request.session['data'] = data
        request.session.set_expiry(TIME_LIMIT)

    # Build url to display for challenge submission    
    url = request.build_absolute_uri("index")
    
    # Set up context data for template
    context = {
        'title': CHALLENGE_TITLE,
        'desc': CHALLENGE_DESCRIPTION,
        'time': TIME_LIMIT,
        'data': data,
        'url': url,
    }

    # Render the challenge template with request and context data
    return render(request, "challenge.html", context)