#requires installing requests-html and lxml_html_clean libraries 

import base64
from requests_html import HTMLSession

session = HTMLSession()
url = "http://127.0.0.1:8000/challenge"
response = session.get(url)
data = response.html.find('.data', first=True)
answer = base64.b64encode(data.text.encode("ascii")).decode()
# Outputs to test base64 encoding against cyberchef or other online encoders
#print(data.text)
#print(answer)

response = session.get(url+'?answer='+answer)
data = response.html.find('.data', first=True)
print(data.text)






