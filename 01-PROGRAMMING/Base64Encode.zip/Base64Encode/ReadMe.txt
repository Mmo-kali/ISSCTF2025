# ----------------------------------------------------------------------
# Black Hat Bureau CTF Programming Challenge:
# Base64Encode
# Dev: Joel Dykstra (OtterTeamSix)
# Last Updated: May 5, 2024
#
# A programming challenge where a user must encode a randomly generated
# 80 byte hex string into base64 and submit it back to the webpage
# within a very short time period (eg: 3 seonds) to successfully retrieve
# the flag. A python file for the solution is included in the folder
#
# TODO: Adjust the challenge description to make it fit into the
#       event theme. Currently, the challenge is functional but needs
#       better CSS styling and the above mentioned theme updates.
# ----------------------------------------------------------------------